# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 16:40:23 2024

@author: Adriana
"""

import pygame

class Player():
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 50
        self.height = 40
        self.color = (0,0,255) #color azul para la nave
        self.velocity = 10
        self.lives = 3
        
    def move(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.x - self.velocity > 0:
            self.x -= self.velocity
        if keys[pygame.K_RIGHT] and self.x + self.velocity < 800 - self.width:
            self.x += self.velocity
        if keys[pygame.K_UP]and self.y - self.velocity > 0:
            self.y -= self.velocity
        if keys[pygame.K_DOWN] and self.y + self.velocity < 600 - self.height:
            self.y += self.velocity
            
    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))