# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 16:40:53 2024

@author: Adriana
"""
import pygame

class Bullet:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = 5
        self.color = (255,140,0) #color naranja para las bullets
        self.velocity = -10 #la bullets se mueve hacia arriba
        
    def move(self):
        self.y += self.velocity #movimiento hacia arriba
        
    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
