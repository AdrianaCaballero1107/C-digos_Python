# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 18:43:50 2024

@author: Adriana
"""
import pygame
import random
from bullets import Bullet
from player import Player

class SpecialEnemy:
    def __init__(self):
        self.x = random.randint(0, 750)
        self.y = random.randint(-100, -40)
        self.width = 65
        self.height = 50
        self.color = (255,215,0)
        self.velocity = random.randint(3, 5)
        self.health = 5
        
    def move(self):
        self.y += self.velocity
        if self.y > 600: #si el enemigo cruza el limite inferior de la pantalla
            self.y = random.randint(-100, -40)
            self.x = random.randint(0, 750)
            
    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))
        
    def collides_with(self, obj):
        if isinstance(obj, Bullet):
            #comprueba si la bala esta dentro del ancho y alto del enemigo
             return(
                self.x < obj.x < self.x + self.width and
                self.y < obj.y < self.y + self.height
              )
        elif isinstance(obj, Player): #deteccion de colision con el jugador
          return(
              self.x < obj.x + obj.width and
              self.x + self.width > obj.x and
              self.y < obj.y + obj.height and
              self.y + self.height > obj.y
              )
        return False
