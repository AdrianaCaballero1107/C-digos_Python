# -*- coding: utf-8 -*-
"""
Created on Thu Nov 14 16:32:52 2024

@author: Adriana
"""
import pygame
from player import Player
from bullets import Bullet
from enemy import Enemy
from special_enemy import SpecialEnemy
import random
import time

#inicializar Pygame
pygame.init()

#configurar la pantalla
WIDTH = 800
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("GALATSIA")

#colores
WHITE = (255,255,255)
BLUE = (0,30,255)
GRAY = (169,169,169)

#inicializar el jugador
player = Player(WIDTH//2, HEIGHT -50)
bullets = []#nueva lista para almacenar las balas
enemies = [] #lista para almacenar todo los enemigos generados
special_enemies = [] #lista para almacenar enemigos especiales
score = 0 #inicializar el sistema de puntaje
level = 1 #inicializar el nivel 1
special_power_ready = True #indica si el poder especial esta disponible
special_power_cooldown = 10000#tiempo de recarga del poder especial en MILISEGUNDOS
last_special_use = 0 #marca de tiempo de la ultima vez que se uso el poder especial
special_enemy_spawn_counter = 0 #contador para la aparicion de enemigos especiales

#contador para controlar la generacion de enemigos
enemy_spawn_counter = 0 #contador que ayudara a añadir enemigos periodicamente
enemy_speed_increase = 0 #incremento de velocidad de enemigos por nivel

#fuente para mostrar las vidas y la puntuacion en pantalla
font = pygame.font.Font(None, 36)
game_over_font = pygame.font.Font(None, 72)

#Bucle principal del juego
running = True
game_over= False #estado para verificar si el juego ha terminado

while running:
    screen.fill(WHITE) #fondo blanco
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
             #crear una bala nueva al presionar la barra espaciadora
               bullets.append(Bullet(player.x + player.width // 2, player.y))
            elif event.key == pygame.K_m and special_power_ready and not game_over:
                enemies.clear()
                special_enemies.clear()
                special_power_ready = False
                last_special_use = pygame.time.get_ticks()
               
    #verificar si el juego ha terminado
    if game_over:
        game_over_text = game_over_font.render("GAME OVER", True, (255,0,0))
        score_text = font.render(f"Puntuacion final: {score}", True, (0,0,0))
        screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width()//2, HEIGHT // 2-50))
        screen.blit(score_text, (WIDTH // 2 - score_text.get_width()//2, HEIGHT // 2 + 20))
        pygame.display.flip() #actualizar pantalla con el mensaje final
        pygame.time.delay(3000)#pausar para que el jugador vea el mensaje
        running = False #cerra el juego despues de mostrar el mensaje
        continue #saltar el resto del bucle para evitar actualizaciones 
        
    #actualizar la barra del poder especial
    current_time = pygame.time.get_ticks() #obtener el tiempo actual en milisegundos
    if not special_power_ready:
        elapsed_time = current_time - last_special_use #tiempo desde la ultima activacion
        if elapsed_time >= special_power_cooldown:
            special_power_ready = True #reactiva el poder despues de la recarga
        else:
            #calcular el ancho de la barra de recarga
            #200 es el ancho de la barra
            bar_width = int((elapsed_time / special_power_cooldown) * 200)
            pygame.draw.rect(screen, GRAY, (10,130,200,20)) #fondo de la barra de recarga
            pygame.draw.rect(screen, BLUE, (10,130, bar_width, 20))
    else:
        #dibiujar la barra llena si el poder esta listo
        pygame.draw.rect(screen, BLUE, (10,130,200,20))
    
    #actualizar nivel y dificultad
    if score >= level * 100: #aumentar nivel cada 100 puntos
          level += 1
          enemy_speed_increase += 1 #aumnetar la velocidad de los enemigos
          #aumentar la frecuencia de generacion de enemigos
          enemy_spawn_counter = max(20, enemy_spawn_counter - 10) 
     
    #generar enemigos periodicamente
    enemy_spawn_counter += 1#incrementa el contador en cada cuadro del juego
    if enemy_spawn_counter >= 60: #cuando el contador llega a 60(aprox 2 seg)
         new_enemy = Enemy()
         new_enemy.velocity += enemy_speed_increase #incrementar velocidad enemigo / nivel
         overlap = any(enemy.collides_with(new_enemy) for enemy in enemies)
         attemps = 0
         while overlap and attemps < 10:
             new_enemy = Enemy()
             new_enemy.velocity += enemy_speed_increase #incrementar velocidad enemigo / nivel
             overlap = any(enemy.collides_with(new_enemy) for enemy in enemies)
             attemps += 1
         if not overlap:
            enemies.append(new_enemy)
         enemy_spawn_counter = 0
         
    #generar enemigos especiales cada 20 segundos
    special_enemy_spawn_counter += 1
    if special_enemy_spawn_counter >= 1200: #1200 iteraciones aprox 20 segundos
          special_enemies.append(SpecialEnemy())
          special_enemy_spawn_counter = 0
            
            #actualizar la posicion del jugador
    player.move()
    player.draw(screen)
    
    #mostrar las vidas y puntuacion en pantalla
    lives_text = font.render(f"Vidas: {player.lives}", True, (0,0,0))
    screen.blit(lives_text, (10,10))
    score_text = font.render(f"Puntuacion: {score}", True, (0,0,0))
    screen.blit(score_text,(10,50))
    level_text = font.render(f"Nivel: {level}", True, (0,0,0))
    screen.blit(level_text, (10,90))
    
    #actualizar y dibujar cada bullet
    for bullet in bullets[:]: #nueva iteracion sobre las bullets
        bullet.move() #movimiento de cada bala
        bullet.draw(screen) #dibujo de cada bullet en la pantalla
        if bullet.y < 0: #eliminar bullets que salen de la pantalla
           bullets.remove(bullet)
           
    #actualizar y dibujar cada enemigo
    for enemy in enemies[:]:
        enemy.move()
        enemy.draw(screen)
        #verificar colisiones entre las balas y los enemigos
        for bullet in bullets:
            if enemy.collides_with(bullet):
                bullets.remove(bullet)
                enemy.health -= 1
                if enemy.health <= 0:
                    enemies.remove(enemy)
                    score += 10 #incrementa la puntuacion cuando se elimina un enemigo
                    
        #verificar colisiones entre el enemigo y el jugador
        if enemy.collides_with(player):
            player.lives -= 1
            enemies.remove(enemy)
            if player.lives <= 0:
                #running = False
                game_over = True
                
    #actualizar y dibujar cada enemigo especial
    for special_enemy in special_enemies[:]:
        special_enemy.move()
        special_enemy.draw(screen)
        
        for bullet in bullets[:]:
            if special_enemy.collides_with(bullet):
                bullets.remove(bullet)
                special_enemy.health -= 1
                if special_enemy.health <= 0:
                   special_enemies.remove(special_enemy)
                   score += 50
                    
        #verificar colisiones entre enemigo especial y jugador
        if special_enemy.collides_with(player):
            player.lives += 2
            special_enemies.remove(special_enemy)
            if player.lives <= 0:
                game_over = True
            
           
    pygame.display.flip()
    pygame.time.delay(30) #suavizar el movimiento del jugador
    
    pygame.display.flip()
    
pygame.quit()
